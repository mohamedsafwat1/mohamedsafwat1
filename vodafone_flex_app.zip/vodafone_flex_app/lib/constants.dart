import 'package:flutter/material.dart';

class AppConstants {
  static const Color vodafoneRed = Color(0xFFE60000);
  static const Color cyanAccent = Color(0xFF00C4B4);
  static const Color yellowAccent = Color(0xFFFFD700);
  static const Color whiteBackground = Colors.white;
}