import 'package:http/http.dart' as http;
import 'dart:convert';

Future<Map<String, dynamic>?> login(String number, String password, Function(String, {bool isError}) updateStatus) async {
  const url = 'https://mobile.vodafone.com.eg/auth/realms/vf-realm/protocol/openid-connect/token';
  final payload = {
    'username': number,
    'password': password,
    'grant_type': 'password',
    'client_secret': 'a2ec6fff-0b7f-4aa4-a733-96ceae5c84c3',
    'client_id': 'my-vodafone-app',
  };
  final headers = {
    'User-Agent': 'okhttp/4.9.3',
    'Accept': 'application/json, text/plain, */*',
    'Accept-Encoding': 'gzip',
    'x-agent-operatingsystem': 'V12.5.13.0.RJQMIXM',
    'clientId': 'xxx',
    'x-agent-device': 'lime',
    'x-agent-version': '2024.10.1',
    'x-agent-build': '562',
  };
  try {
    final response = await http.post(Uri.parse(url), body: payload, headers: headers);
    final data = jsonDecode(response.body);
    if (data.containsKey('access_token')) {
      updateStatus('تسجيل الدخول نجح لرقم $number');
      return data;
    } else {
      updateStatus('فشل تسجيل الدخول. تحقق من الرقم أو الباسورد.', isError: true);
      return null;
    }
  } catch (e) {
    updateStatus('خطأ في تسجيل الدخول: $e', isError: true);
    return null;
  }
}

Future<void> log(String numberOwner, String passwordOwner, String numberMember1, String numberMember2, Function(String, {bool isError}) updateStatus) async {
  final loginResponse = await login(numberOwner, passwordOwner, updateStatus);
  if (loginResponse == null) return;

  final accessToken = 'Bearer ${loginResponse['access_token']}';
  updateStatus('🔄 جاري تغيير الكوته إلى 1300');

  const url = 'https://web.vodafone.com.eg/services/dxl/cg/customerGroupAPI/customerGroup';
  final payload = {
    'name': 'FlexFamily',
    'type': 'QuotaRedistribution',
    'category': [
      {'value': '523', 'listHierarchyId': 'PackageID'},
      {'value': '47', 'listHierarchyId': 'TemplateID'},
      {'value': '523', 'listHierarchyId': 'TierID'},
      {'value': 'percentage', 'listHierarchyId': 'familybehavior'},
    ],
    'parts': {
      'member': [
        {'id': [{'value': numberOwner, 'schemeName': 'MSISDN'}], 'type': 'Owner'},
        {'id': [{'value': numberMember1, 'schemeName': 'MSISDN'}], 'type': 'Member'},
      ],
      'characteristicsValue': {
        'characteristicsValue': [
          {'characteristicName': 'quotaDist1', 'value': '10', 'type': 'percentage'},
        ],
      },
    },
  };
  final headers = {
    'User-Agent': 'Mozilla/5.0 (Linux; Android 11; M2010J19SG) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.85 Mobile Safari/537.36',
    'Accept': 'application/json',
    'Content-Type': 'application/json',
    'sec-ch-ua': '"Chromium";v="94", "Google Chrome";v="94", ";Not A Brand";v="99"',
    'msisdn': numberOwner,
    'Accept-Language': 'AR',
    'sec-ch-ua-mobile': '?1',
    'Authorization': accessToken,
    'x-dtpc': '5$160966758_702h19vRCUAEMOMIIASTHWKLEMFNIHJNUTANVVK-0e0',
    'clientId': 'WebsiteConsumer',
    'sec-ch-ua-platform': '"Android"',
    'Origin': 'https://web.vodafone.com.eg',
    'Sec-Fetch-Site': 'same-origin',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://web.vodafone.com.eg/spa/familySharing',
  };

  try {
    final response = await http.post(Uri.parse(url), body: jsonEncode(payload), headers: headers);
    updateStatus('📤 رد توزيع الكوته: ${response.body}');
    await Future.delayed(const Duration(seconds: 300)); // 5 دقايق
    updateStatus('📩 جاري إرسال دعوة للعضو الثاني...');

    final invitationPayload = {
      'name': 'FlexFamily',
      'type': 'SendInvitation',
      'category': [
        {'value': '523', 'listHierarchyId': 'PackageID'},
        {'value': '47', 'listHierarchyId': 'TemplateID'},
        {'value': '523', 'listHierarchyId': 'TierID'},
        {'value': 'percentage', 'listHierarchyId': 'familybehavior'},
      ],
      'parts': {
        'member': [
          {'id': [{'value': numberOwner, 'schemeName': 'MSISDN'}], 'type': 'Owner'},
          {'id': [{'value': numberMember2, 'schemeName': 'MSISDN'}], 'type': 'Member'},
        ],
        'characteristicsValue': {
          'characteristicsValue': [
            {'characteristicName': 'quotaDist1', 'value': '10', 'type': 'percentage'},
          ],
        },
      },
    };
    final invitationResponse = await http.post(Uri.parse(url), body: jsonEncode(invitationPayload), headers: headers);
    updateStatus('📤 رد الدعوة: ${invitationResponse.body}');
  } catch (e) {
    updateStatus('خطأ في توزيع الكوته أو إرسال الدعوة: $e', isError: true);
  }
}

Future<void> acceptInvitation(String accessToken, String numberOwner, String numberMember2, Function(String, {bool isError}) updateStatus) async {
  const url = 'https://mobile.vodafone.com.eg/services/dxl/cg/customerGroupAPI/customerGroup';
  final payload = {
    'category': [{'listHierarchyId': 'TemplateID', 'value': '47'}],
    'name': 'FlexFamily',
    'parts': {
      'member': [
        {'id': [{'schemeName': 'MSISDN', 'value': numberOwner}], 'type': 'Owner'},
        {'id': [{'schemeName': 'MSISDN', 'value': numberMember2}], 'type': 'Member'},
      ],
    },
    'type': 'AcceptInvitation',
  };
  final headers = {
    'User-Agent': 'okhttp/4.11.0',
    'Connection': 'Keep-Alive',
    'Accept': 'application/json',
    'Accept-Encoding': 'gzip',
    'Content-Type': 'application/json',
    'api_id': 'APP',
    'x-dynatrace': 'MT_3_24_3486379639_64-0_a556db1b-4506-43f3-854a-1d2527767923_0_187_277',
    'Authorization': 'Bearer $accessToken',
    'api-version': 'v2',
    'x-agent-operatingsystem': '13',
    'clientId': 'AnaVodafoneAndroid',
    'x-agent-device': 'Xiaomi 21061119AG',
    'x-agent-version': '2024.12.1',
    'x-agent-build': '946',
    'msisdn': numberMember2,
    'Accept-Language': 'ar',
  };

  try {
    final response = await http.patch(Uri.parse(url), body: jsonEncode(payload), headers: headers);
    updateStatus('📩 تم قبول الدعوة بنجاح! (الحالة: ${response.statusCode})');
  } catch (e) {
    updateStatus('خطأ في قبول الدعوة: $e', isError: true);
  }
}

Future<void> adjustQuota(String accessToken, String numberOwner, String numberMember1, Function(String, {bool isError}) updateStatus) async {
  const url = 'https://web.vodafone.com.eg/services/dxl/cg/customerGroupAPI/customerGroup';
  final payload = {
    'name': 'FlexFamily',
    'type': 'QuotaRedistribution',
    'category': [
      {'value': '523', 'listHierarchyId': 'PackageID'},
      {'value': '47', 'listHierarchyId': 'TemplateID'},
      {'value': '523', 'listHierarchyId': 'TierID'},
      {'value': 'percentage', 'listHierarchyId': 'familybehavior'},
    ],
    'parts': {
      'member': [
        {'id': [{'value': numberOwner, 'schemeName': 'MSISDN'}], 'type': 'Owner'},
        {'id': [{'value': numberMember1, 'schemeName': 'MSISDN'}], 'type': 'Member'},
      ],
      'characteristicsValue': {
        'characteristicsValue': [
          {'characteristicName': 'quotaDist1', 'value': '40', 'type': 'percentage'},
        ],
      },
    },
  };
  final headers = {
    'User-Agent': 'Mozilla/5.0 (Linux; Android 11; M2010J19SG) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.85 Mobile Safari/537.36',
    'Accept': 'application/json',
    'Content-Type': 'application/json',
    'sec-ch-ua': '"Chromium";v="94", "Google Chrome";v="94", ";Not A Brand";v="99"',
    'msisdn': numberOwner,
    'Accept-Language': 'AR',
    'sec-ch-ua-mobile': '?1',
    'Authorization': 'Bearer $accessToken',
    'x-dtpc': '5$160966758_702h19vRCUAEMOMIIASTHWKLEMFNIHJNUTANVVK-0e0',
    'clientId': 'WebsiteConsumer',
    'sec-ch-ua-platform': '"Android"',
    'Origin': 'https://web.vodafone.com.eg',
    'Sec-Fetch-Site': 'same-origin',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://web.vodafone.com.eg/spa/familySharing',
  };

  try {
    final response = await http.post(Uri.parse(url), body: jsonEncode(payload), headers: headers);
    updateStatus('🔄 تم تغيير الكوته إلى 40% بنجاح! (الحالة: ${response.statusCode})');
  } catch (e) {
    updateStatus('خطأ في تغيير الكوته: $e', isError: true);
  }
}

Future<void> delete(String numberOwner, String passwordOwner, String numberMember2, Function(String, {bool isError}) updateStatus) async {
  final loginResponse = await login(numberOwner, passwordOwner, updateStatus);
  if (loginResponse == null) return;

  final accessToken = 'Bearer ${loginResponse['access_token']}';
  updateStatus('🗑️ جاري حذف العضو الثاني...');

  const url = 'https://web.vodafone.com.eg/services/dxl/cg/customerGroupAPI/customerGroup';
  final payload = {
    'name': 'FlexFamily',
    'type': 'FamilyRemoveMember',
    'category': [{'value': '47', 'listHierarchyId': 'TemplateID'}],
    'parts': {
      'member': [
        {'id': [{'value': numberOwner, 'schemeName': 'MSISDN'}], 'type': 'Owner'},
        {'id': [{'value': numberMember2, 'schemeName': 'MSISDN'}], 'type': 'Member'},
      ],
      'characteristicsValue': {
        'characteristicsValue': [
          {'characteristicName': 'Disconnect', 'value': '0'},
          {'characteristicName': 'LastMemberDeletion', 'value': '1'},
        ],
      },
    },
  };
  final headers = {
    'User-Agent': 'Mozilla/5.0 (Linux; Android 11; M2010J19SG) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.85 Mobile Safari/537.36',
    'Accept': 'application/json',
    'Content-Type': 'application/json',
    'sec-ch-ua': '"Chromium";v="94", "Google Chrome";v="94", ";Not A Brand";v="99"',
    'msisdn': numberOwner,
    'Accept-Language': 'AR',
    'sec-ch-ua-mobile': '?1',
    'Authorization': accessToken,
    'x-dtpc': '8$160966758_702h28vFSPMIAKHHWGIIKVDPLHCDFHKOJUBFNJP-0e0',
    'clientId': 'WebsiteConsumer',
    'sec-ch-ua-platform': '"Android"',
    'Origin': 'https://web.vodafone.com.eg',
    'Sec-Fetch-Site': 'same-origin',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://web.vodafone.com.eg/spa/familySharing',
  };

  try {
    final response = await http.patch(Uri.parse(url), body: jsonEncode(payload), headers: headers);
    updateStatus('🗑️ رد حذف العضو: ${response.body}');
    await Future.delayed(const Duration(seconds: 300)); // 5 دقايق
  } catch (e) {
    updateStatus('خطأ في حذف العضو: $e', isError: true);
  }
}