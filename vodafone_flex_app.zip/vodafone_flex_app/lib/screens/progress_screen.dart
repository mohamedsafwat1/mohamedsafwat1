import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import '../services/api_services.dart';

class ProgressScreen extends StatefulWidget {
  final String numberOwner, passwordOwner, numberMember1, passwordMember1, numberMember2, passwordMember2;
  final int cycles;

  const ProgressScreen({
    super.key,
    required this.numberOwner,
    required this.passwordOwner,
    required this.numberMember1,
    required this.passwordMember1,
    required this.numberMember2,
    required this.passwordMember2,
    required this.cycles,
  });

  @override
  _ProgressScreenState createState() => _ProgressScreenState();
}

class _ProgressScreenState extends State<ProgressScreen> {
  String status = '';
  int currentCycle = 1;
  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    startCycles();
  }

  Future<void> startCycles() async {
    for (int i = 1; i <= widget.cycles; i++) {
      setState(() {
        status += '\n🔄 بدء الدورة $i من ${widget.cycles}\n';
        isLoading = true;
      });

      await log(widget.numberOwner, widget.passwordOwner, widget.numberMember1, widget.numberMember2, updateStatus);

      setState(() => status += '\n🔐 تسجيل الدخول...\n');
      final ownerLogin = await login(widget.numberOwner, widget.passwordOwner, updateStatus);
      final member1Login = await login(widget.numberMember1, widget.passwordMember1, updateStatus);
      final member2Login = await login(widget.numberMember2, widget.passwordMember2, updateStatus);

      if (ownerLogin != null && member1Login != null && member2Login != null) {
        setState(() => status += '\n✅ تسجيل الدخول نجح للجميع!\n');
        await Future.wait([
          acceptInvitation(member2Login['access_token'], widget.numberOwner, widget.numberMember2, updateStatus),
          adjustQuota(ownerLogin['access_token'], widget.numberOwner, widget.numberMember1, updateStatus),
        ]);
        await countdown(3, '⏳ الخطوة التالية خلال');
        await delete(widget.numberOwner, widget.passwordOwner, widget.numberMember2, updateStatus);
      } else {
        setState(() => status += '\n❌ فشل تسجيل الدخول، جاري إعادة المحاولة...\n');
        await countdown(30, '⏳ إعادة المحاولة خلال');
        continue;
      }

      setState(() {
        status += '\n✅ الدورة $i خلّصت بنجاح!\n';
        isLoading = false;
        currentCycle++;
      });

      if (i < widget.cycles) {
        await countdown(300, '⏳ الدورة التالية خلال');
      }
    }
    setState(() => status += '\n🎉 كل العمليات خلّصت بنجاح!\n👨‍💻 المطور: محمد ناصر');
  }

  Future<void> countdown(int seconds, String message) async {
    for (int i = seconds; i >= 0; i--) {
      setState(() => status += '\n$message: ${i ~/ 60}:${(i % 60).toString().padLeft(2, '0')}');
      await Future.delayed(const Duration(seconds: 1));
    }
  }

  void updateStatus(String message, {bool isError = false}) {
    setState(() => status += '\n${isError ? '❌' : '✅'} $message');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('تقدم الدورات - $currentCycle/${widget.cycles}'),
        backgroundColor: const Color(0xFFE60000),
      ),
      body: Directionality(
        textDirection: TextDirection.rtl,
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              if (isLoading)
                const SpinKitCircle(color: Color(0xFFE60000), size: 50.0),
              const SizedBox(height: 20),
              Expanded(
                child: SingleChildScrollView(
                  child: Text(
                    status,
                    style: const TextStyle(fontSize: 16, color: Colors.black87),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}